import { Injectable } from "@angular/core";
import { Observable, BehaviorSubject } from "rxjs/Rx";

@Injectable()
export class DataService {
    public dataObject:BehaviorSubject<any>= new BehaviorSubject<any>({});
    private fetchingData:BehaviorSubject<any>= new BehaviorSubject<boolean>(true);

    watchDataObject$= this.dataObject.asObservable();
    watchFetchingData$= this.fetchingData.asObservable();

    constructor() {}

    setDataObject(dataObj: any){
        console.log("ye dkho", dataObj);
        this.dataObject.next(dataObj);
    }
    setFetchingData(fetchingData: boolean){
        console.log("ye dkho", fetchingData);
        this.fetchingData.next(fetchingData);
    }
    getFetchingData(){
        // console.log("ye dkho", fetchingData);
        return this.fetchingData.getValue();
    }
}
