import { Injectable } from "@angular/core";
import { Response, Http, Headers } from "@angular/http";
// import { Router } from "@angular/router";
import "rxjs/add/operator/map";
import "rxjs/add/operator/catch";
import { Observable } from "rxjs/Rx";

const API_HOST= 'http://localhost:3030';

@Injectable()
export class HttpService {
  service: any = {};
  authHttp: any = {};
  authenticatedAPI: boolean = true; //checks for authenticated http request (authHttp) or non-authenticated http request (http)

  constructor(
    protected http: Http,
    // private router: Router
  ) {
  }

  // buildUrl(parameters): string {
  //   let qs = "";
  //   for (const key of Object.keys(parameters)) {
  //     const value = parameters[key];
  //     // if (value) {
  //     qs += encodeURIComponent(key) + "=" + encodeURIComponent(value) + "&";
  //     // }
  //   }
  //   if (qs.length > 0) {
  //     qs = qs.substring(0, qs.length - 1); //chop off last "&"
  //   }
  //   return qs;
  // }

  // get(url: string, elementID: any, headers: any = null): Observable<any> {
  //   console.log("Inside http service", url, elementID, headers);
  //   this.service = this.authenticatedAPI ? this.authHttp : this.http;
  //   return this.service
  //     .get(`${API_HOST}/api/${url}/` + elementID)
  //     .map((response: Response) => {
  //       return response.json();
  //     });
  // }

  post(url: string, element: any): Observable<any> {
    // this.service = this.authenticatedAPI ? this.authHttp : this.http;
    return this.http
      .post(`${API_HOST}/api/${url}/`, element)
      .map((response: Response) => {
        return response.json();
      })
      .catch(err => {
        console.log("Inside http store error", JSON.parse(JSON.stringify(err)));
        // return this.handleErrorResponse(err);
        return Observable.throw(err.json());
      });
    }
}
