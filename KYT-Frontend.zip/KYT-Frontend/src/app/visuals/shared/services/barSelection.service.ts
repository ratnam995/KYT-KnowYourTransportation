import { Injectable } from "@angular/core";
import { Observable, BehaviorSubject } from "rxjs/Rx";

@Injectable()
export class BarSelectionService {
    private currentSelectionObject:BehaviorSubject<any>= new BehaviorSubject<any>({});
    public currentSelectedMode:string="None";
    watchCurrentSelectionObject$= this.currentSelectionObject.asObservable();



    constructor() {}

    setCurrentSelectionObject(currentSelectionObj: any){
        console.log("ye dkho", currentSelectionObj);
        this.currentSelectionObject.next(currentSelectionObj);
    }
}
