export interface Frequency {
    mode: string;
    frequency: number;
    duration: number;
    distance: number;
}

export const STATISTICS: Frequency[] = [
    {mode: 'Car', frequency: 235, duration: 867.78, distance: 45},
    {mode: 'Walking', frequency: 134, duration: 167.78, distance: 15},
    {mode: 'Bike', frequency: 564, duration: 267.78, distance: 25},
    {mode: 'Bus', frequency: 456, duration: 997.78, distance: 51},
    {mode: 'Train', frequency: 112, duration: 17.78, distance: 1}
];