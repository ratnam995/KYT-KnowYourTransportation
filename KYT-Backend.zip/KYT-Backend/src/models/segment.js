module.exports = (sequelize, DataTypes) => {
    const Segment = sequelize.define(
      'Segment',
      {
        idTag : { type: DataTypes.STRING, allowNull: false },
        display_name : { type: DataTypes.STRING, allowNull: false },
        description : { type: DataTypes.STRING, allowNull: false },
      },
      {
        underscored: true,
      }
    );
  
    // Segment.associate = models => {
    // //   Segment.hasMany(models.Date);
    //   Segment.belongsTo(models.Segment, {
    //     onDelete: 'CASCADE',
    //     foreignKey: {
    //       allowNull: false,
    //     },
    //   });
    // };
  
    return Segment;
  };
  