//  transport_mode, duration, count, distance
module.exports = (sequelize, DataTypes) => {
  const AggregateField = sequelize.define(
    'AggregateField',
    {
      transport_mode: { type: DataTypes.STRING },
      duration: { type: DataTypes.DECIMAL },
      count: { type: DataTypes.INTEGER },
      distance: { type: DataTypes.INTEGER },
      // timeRange: {type: DataTypes.}
    },
    {
      underscored: true,
    }
  );

  // AggregateField.associate = models => {
  // //   AggregateField.hasMany(models.Date);
  //   AggregateField.belongsTo(models.AggregateField, {
  //     onDelete: 'CASCADE',
  //     foreignKey: {
  //       allowNull: false,
  //     },
  //   });
  // };

  return AggregateField;
};
